java -cp ./out/production/game-of-life com.demo.Life
