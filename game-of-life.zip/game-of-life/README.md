# game-of-life
#Run the program
#Mac
sh run.sh

#windows
run.bat